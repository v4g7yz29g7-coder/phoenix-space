// app.js - AI Photo Story Builder

class PhotoStoryBuilder {
    constructor() {
        this.state = {
            photos: [],
            selectedPhotos: [],
            currentTemplate: null,
            generatedVariants: [],
            activeVariant: 0,
            gapSize: 10,
            marginSize: 20,
            autoSpacing: true,
            format: 'instagram',
            projectHistory: [],
            isGenerating: false,
            exportFormat: 'png'
        };

        this.elements = {
            dropZone: document.getElementById('dropZone'),
            fileInput: document.getElementById('fileInput'),
            photoGrid: document.getElementById('photoGrid'),
            templateLibrary: document.getElementById('templateLibrary'),
            generateBtn: document.getElementById('generateBtn'),
            variantsContainer: document.getElementById('variantsContainer'),
            gapSlider: document.getElementById('gapSlider'),
            marginSlider: document.getElementById('marginSlider'),
            autoSpacingToggle: document.getElementById('autoSpacingToggle'),
            formatSelector: document.getElementById('formatSelector'),
            aiCommandInput: document.getElementById('aiCommandInput'),
            aiCommandBtn: document.getElementById('aiCommandBtn'),
            exportBtn: document.getElementById('exportBtn'),
            historyList: document.getElementById('historyList'),
            loadingOverlay: document.getElementById('loadingOverlay'),
            previewCanvas: document.getElementById('previewCanvas')
        };

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadTemplates();
        this.loadProjectHistory();
        this.initCanvas();
    }

    setupEventListeners() {
        // Drag and drop
        this.elements.dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.elements.dropZone.classList.add('dragover');
        });

        this.elements.dropZone.addEventListener('dragleave', () => {
            this.elements.dropZone.classList.remove('dragover');
        });

        this.elements.dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            this.elements.dropZone.classList.remove('dragover');
            const files = Array.from(e.dataTransfer.files);
            this.handleFiles(files);
        });

        // File input
        this.elements.fileInput.addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            this.handleFiles(files);
        });

        // Generate button
        this.elements.generateBtn.addEventListener('click', () => {
            this.generateVariants();
        });

        // Sliders
        this.elements.gapSlider.addEventListener('input', (e) => {
            this.state.gapSize = parseInt(e.target.value);
            this.state.autoSpacing = false;
            this.elements.autoSpacingToggle.checked = false;
            this.updatePreview();
        });

        this.elements.marginSlider.addEventListener('input', (e) => {
            this.state.marginSize = parseInt(e.target.value);
            this.state.autoSpacing = false;
            this.elements.autoSpacingToggle.checked = false;
            this.updatePreview();
        });

        // Auto spacing toggle
        this.elements.autoSpacingToggle.addEventListener('change', (e) => {
            this.state.autoSpacing = e.target.checked;
            if (this.state.autoSpacing) {
                this.calculateAutoSpacing();
            }
        });

        // Format selector
        this.elements.formatSelector.addEventListener('change', (e) => {
            this.state.format = e.target.value;
            this.updatePreview();
        });

        // AI command
        this.elements.aiCommandBtn.addEventListener('click', () => {
            this.processAICommand(this.elements.aiCommandInput.value);
        });

        this.elements.aiCommandInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.processAICommand(this.elements.aiCommandInput.value);
            }
        });

        // Export
        this.elements.exportBtn.addEventListener('click', () => {
            this.exportProject();
        });
    }

    handleFiles(files) {
        const imageFiles = files.filter(file => file.type.startsWith('image/'));
        
        imageFiles.forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const photo = {
                    id: Date.now() + Math.random(),
                    src: e.target.result,
                    name: file.name,
                    metadata: {}
                };
                
                // Analyze image
                this.analyzeImage(photo).then(metadata => {
                    photo.metadata = metadata;
                    this.state.photos.push(photo);
                    this.state.selectedPhotos.push(photo);
                    this.renderPhotoGrid();
                    this.updatePreview();
                });
            };
            reader.readAsDataURL(file);
        });
    }

    async analyzeImage(photo) {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                
                // Basic analysis
                const metadata = {
                    width: img.width,
                    height: img.height,
                    orientation: img.width > img.height ? 'landscape' : 'portrait',
                    aspectRatio: img.width / img.height,
                    brightness: this.calculateBrightness(ctx, img.width, img.height),
                    dominantColors: this.extractDominantColors(ctx, img.width, img.height)
                };
                
                resolve(metadata);
            };
            img.src = photo.src;
        });
    }

    calculateBrightness(ctx, width, height) {
        const imageData = ctx.getImageData(0, 0, width, height);
        const data = imageData.data;
        let sum = 0;
        for (let i = 0; i < data.length; i += 4) {
            sum += (data[i] + data[i + 1] + data[i + 2]) / 3;
        }
        return sum / (width * height);
    }

    extractDominantColors(ctx, width, height) {
        const imageData = ctx.getImageData(0, 0, width, height);
        const data = imageData.data;
        const colorMap = {};
        
        for (let i = 0; i < data.length; i += 16) {
            const r = Math.round(data[i] / 32) * 32;
            const g = Math.round(data[i + 1] / 32) * 32;
            const b = Math.round(data[i + 2] / 32) * 32;
            const key = `${r},${g},${b}`;
            colorMap[key] = (colorMap[key] || 0) + 1;
        }
        
        return Object.entries(colorMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([key]) => key.split(',').map(Number));
    }

    load
