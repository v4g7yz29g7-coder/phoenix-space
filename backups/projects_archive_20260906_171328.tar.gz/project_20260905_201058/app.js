// app.js - AI Photo Story Builder

// ===== STATE MANAGEMENT =====
const state = {
    photos: [],
    selectedPhotos: [],
    currentProject: null,
    projects: [],
    settings: {
        gap: 10,
        margin: 20,
        autoGap: true,
        autoMargin: true,
        format: 'instagram',
        theme: 'light'
    },
    generatedVariants: [],
    activeVariant: 0,
    isGenerating: false,
    aiCommand: '',
    selectedTemplate: null,
    templates: [],
    exportFormat: 'png',
    user: null
};

// ===== DOM ELEMENTS =====
const elements = {
    dropZone: document.getElementById('dropZone'),
    fileInput: document.getElementById('fileInput'),
    photoGrid: document.getElementById('photoGrid'),
    generateBtn: document.getElementById('generateBtn'),
    variantContainer: document.getElementById('variantContainer'),
    gapSlider: document.getElementById('gapSlider'),
    marginSlider: document.getElementById('marginSlider'),
    autoGapCheckbox: document.getElementById('autoGap'),
    autoMarginCheckbox: document.getElementById('autoMargin'),
    templateLibrary: document.getElementById('templateLibrary'),
    aiCommandInput: document.getElementById('aiCommandInput'),
    aiCommandBtn: document.getElementById('aiCommandBtn'),
    exportBtn: document.getElementById('exportBtn'),
    formatSelect: document.getElementById('formatSelect'),
    themeSelect: document.getElementById('themeSelect'),
    projectList: document.getElementById('projectList'),
    saveProjectBtn: document.getElementById('saveProjectBtn'),
    loadingOverlay: document.getElementById('loadingOverlay'),
    toast: document.getElementById('toast')
};

// ===== TEMPLATE LIBRARY =====
const templateLibrary = [
    {
        id: 'trio-vertical',
        name: 'Трио вертикальных',
        description: '3 вертикальных кадра крупным планом',
        layout: 'grid-3-vertical',
        preview: '📱📱📱'
    },
    {
        id: 'alternating',
        name: 'Чередование планов',
        description: 'Крупный и общий план чередуются',
        layout: 'alternating',
        preview: '🖼️📐🖼️'
    },
    {
        id: 'gallery',
        name: 'Галерейная подача',
        description: 'Равномерная сетка для галереи',
        layout: 'grid-uniform',
        preview: '🔲🔲🔲'
    },
    {
        id: 'story-teller',
        name: 'Сторителлинг',
        description: 'История: эмоция → детали → кульминация',
        layout: 'story-sequence',
        preview: '📖✨🎬'
    },
    {
        id: 'minimal',
        name: 'Минимализм',
        description: 'Много воздуха, чистые линии',
        layout: 'minimal-white',
        preview: '⬜⬜⬜'
    },
    {
        id: 'dynamic',
        name: 'Динамичный',
        description: 'Смелые ракурсы, крупные планы',
        layout: 'dynamic-grid',
        preview: '⚡📸⚡'
    },
    {
        id: 'magazine',
        name: 'Журнальный стиль',
        description: 'Элегантная компоновка как в глянце',
        layout: 'magazine-layout',
        preview: '📰✨📰'
    },
    {
        id: 'wedding-story',
        name: 'Свадебная история',
        description: 'Эмоция, детали, гости, кульминация',
        layout: 'wedding-sequence',
        preview: '💍💐🎉'
    }
];

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

async function initApp() {
    // Load templates
    state.templates = templateLibrary;
    renderTemplateLibrary();
    
    // Setup event listeners
    setupEventListeners();
    
    // Load projects from localStorage
    loadProjects();
    
    // Check for saved session
    const savedSession = localStorage.getItem('photoStorySession');
    if (savedSession) {
        try {
            const session = JSON.parse(savedSession);
            state.user = session.user;
            state.projects = session.projects || [];
            renderProjects();
        } catch (e) {
            console.error('Error loading session:', e);
        }
    }
    
    // Initialize AI engine
    await initAIEngine();
    
    // Show welcome toast
    showToast('Добро пожаловать! Загрузите фото, чтобы начать ✨');
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
    // File upload
    elements.dropZone.addEventListener('click', () => elements.fileInput.click());
    elements.dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        elements.dropZone.classList.add('drag-over');
    });
    elements.dropZone.addEventListener('dragleave', () => {
        elements.dropZone.classList.remove('drag-over');
    });
    elements.dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        elements.dropZone.classList.remove('drag-over');
        handleFiles(e.dataTransfer.files);
    });
    elements.fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });
    
    // Generate button
    elements.generateBtn.addEventListener('click', generateVariants);
    
    // Sliders
    elements.gapSlider.addEventListener('input', (e) => {
        state.settings.gap = parseInt(e.target.value);
        elements.autoGapCheckbox.checked = false;
        state.settings.autoGap = false;
        updateSliderLabels();
        if (state.generatedVariants.length > 0) {
            renderVariant(state.activeVariant);
        }
    });
    
    elements.marginSlider.addEventListener('input', (e) => {
        state.settings.margin = parseInt(e.target.value);
        elements.autoMarginCheckbox.checked = false;
        state.settings.autoMargin = false;
        updateSliderLabels();
        if (state.generatedVariants.length > 0) {
            renderVariant(state.activeVariant);
        }
    });
    
    // Auto checkboxes
    elements.autoGapCheckbox.addEventListener('change', (e) => {
        state.settings.autoGap = e.target.checked;
        if (e.target.checked) {
            elements.gapSlider.disabled = true;
            // AI will suggest optimal gap
            suggestOptimalGap();
        } else {
            elements.gapSlider.disabled = false;
        }
    });
    
    elements.autoMarginCheckbox.addEventListener('change', (e) => {
        state.settings.autoMargin = e.target.checked;
        if (e.target.checked) {
            elements.marginSlider.disabled =
