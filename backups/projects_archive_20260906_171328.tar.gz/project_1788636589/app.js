const app = document.getElementById('app');

app.innerHTML = `
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background: #0a0a0f;
      color: #e0e0e0;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .landing {
      max-width: 1200px;
      width: 100%;
      text-align: center;
    }

    .hero-title {
      font-size: clamp(2.5rem, 6vw, 4.5rem);
      font-weight: 800;
      background: linear-gradient(135deg, #7c3aed, #ec4899);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 1rem;
      letter-spacing: -0.02em;
    }

    .hero-subtitle {
      font-size: clamp(1rem, 2vw, 1.25rem);
      color: #a0a0b0;
      max-width: 700px;
      margin: 0 auto 4rem;
      opacity: 0.8;
    }

    .services-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 2rem;
      margin-bottom: 4rem;
    }

    .service-card {
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 16px;
      padding: 2.5rem 2rem;
      transition: all 0.3s ease;
      backdrop-filter: blur(10px);
      position: relative;
      overflow: hidden;
    }

    .service-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: linear-gradient(90deg, #7c3aed, #ec4899);
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    .service-card:hover {
      transform: translateY(-8px);
      border-color: rgba(124, 58, 237, 0.4);
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
    }

    .service-card:hover::before {
      opacity: 1;
    }

    .service-icon {
      font-size: 3rem;
      margin-bottom: 1.5rem;
      display: block;
    }

    .service-title {
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 1rem;
      color: #ffffff;
    }

    .service-description {
      color: #a0a0b0;
      font-size: 0.95rem;
      margin-bottom: 1.5rem;
    }

    .service-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      justify-content: center;
    }

    .tag {
      background: rgba(124, 58, 237, 0.15);
      color: #a78bfa;
      padding: 0.25rem 0.75rem;
      border-radius: 20px;
      font-size: 0.8rem;
      border: 1px solid rgba(124, 58, 237, 0.3);
    }

    .cta-button {
      background: linear-gradient(135deg, #7c3aed, #ec4899);
      color: white;
      border: none;
      padding: 1.2rem 3.5rem;
      font-size: 1.1rem;
      font-weight: 600;
      border-radius: 50px;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 10px 30px rgba(124, 58, 237, 0.3);
      letter-spacing: 0.02em;
    }

    .cta-button:hover {
      transform: scale(1.05);
      box-shadow: 0 15px 40px rgba(124, 58, 237, 0.5);
    }

    .cta-button:active {
      transform: scale(0.98);
    }

    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.8);
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      visibility: hidden;
      transition: all 0.3s ease;
      backdrop-filter: blur(5px);
      z-index: 1000;
    }

    .modal-overlay.active {
      opacity: 1;
      visibility: visible;
    }

    .modal {
      background: #1a1a2e;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      padding: 3rem;
      max-width: 500px;
      width: 90%;
      text-align: center;
      transform: scale(0.9);
      transition: transform 0.3s ease;
    }

    .modal-overlay.active .modal {
      transform: scale(1);
    }

    .modal-title {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 1rem;
      background: linear-gradient(135deg, #7c3aed, #ec4899);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .modal-text {
      color: #a0a0b0;
      margin-bottom: 2rem;
    }

    .modal-close {
      background: rgba(255, 255, 255, 0.1);
      color: white;
      border: 1px solid rgba(255, 255, 255, 0.2);
      padding: 0.8rem 2rem;
      border-radius: 50px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 0.95
