// app.js - AI Photo Story Builder

class PhotoStoryBuilder {
    constructor() {
        this.state = {
            photos: [],
            selectedPhotos: [],
            currentLayout: null,
            layouts: [],
            gapSize: 10,
            marginSize: 20,
            autoSpacing: true,
            format: 'instagram',
            projectHistory: [],
            currentProject: null,
            isGenerating: false,
            generatedVariants: []
        };

        this.elements = {};
        this.init();
    }

    init() {
        this.cacheElements();
        this.bindEvents();
        this.loadProjectHistory();
        this.initDragAndDrop();
        this.initAIEngine();
        this.render();
    }

    cacheElements() {
        this.elements = {
            uploadZone: document.getElementById('upload-zone'),
            fileInput: document.getElementById('file-input'),
            photoGrid: document.getElementById('photo-grid'),
            layoutPreview: document.getElementById('layout-preview'),
            gapSlider: document.getElementById('gap-slider'),
            marginSlider: document.getElementById('margin-slider'),
            autoSpacingToggle: document.getElementById('auto-spacing'),
            formatSelector: document.getElementById('format-selector'),
            generateBtn: document.getElementById('generate-btn'),
            variantsContainer: document.getElementById('variants-container'),
            aiCommandInput: document.getElementById('ai-command'),
            aiCommandBtn: document.getElementById('ai-command-btn'),
            templateLibrary: document.getElementById('template-library'),
            exportBtn: document.getElementById('export-btn'),
            projectHistoryContainer: document.getElementById('project-history'),
            loadingIndicator: document.getElementById('loading-indicator')
        };
    }

    bindEvents() {
        // Upload events
        this.elements.uploadZone.addEventListener('click', () => this.elements.fileInput.click());
        this.elements.uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.elements.uploadZone.classList.add('dragover');
        });
        this.elements.uploadZone.addEventListener('dragleave', () => {
            this.elements.uploadZone.classList.remove('dragover');
        });
        this.elements.uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            this.elements.uploadZone.classList.remove('dragover');
            this.handleFiles(e.dataTransfer.files);
        });
        this.elements.fileInput.addEventListener('change', (e) => {
            this.handleFiles(e.target.files);
        });

        // Slider events
        this.elements.gapSlider.addEventListener('input', (e) => {
            this.state.gapSize = parseInt(e.target.value);
            this.state.autoSpacing = false;
            this.elements.autoSpacingToggle.checked = false;
            this.updateLayout();
        });

        this.elements.marginSlider.addEventListener('input', (e) => {
            this.state.marginSize = parseInt(e.target.value);
            this.state.autoSpacing = false;
            this.elements.autoSpacingToggle.checked = false;
            this.updateLayout();
        });

        // Auto spacing toggle
        this.elements.autoSpacingToggle.addEventListener('change', (e) => {
            this.state.autoSpacing = e.target.checked;
            if (this.state.autoSpacing) {
                this.calculateOptimalSpacing();
            }
        });

        // Format selector
        this.elements.formatSelector.addEventListener('change', (e) => {
            this.state.format = e.target.value;
            this.updateLayout();
        });

        // Generate button
        this.elements.generateBtn.addEventListener('click', () => this.generateVariants());

        // AI command
        this.elements.aiCommandBtn.addEventListener('click', () => this.processAICommand());
        this.elements.aiCommandInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.processAICommand();
        });

        // Export
        this.elements.exportBtn.addEventListener('click', () => this.exportProject());
    }

    handleFiles(files) {
        const imageFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
        
        imageFiles.forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const photo = {
                    id: Date.now() + Math.random(),
                    src: e.target.result,
                    name: file.name,
                    type: file.type,
                    metadata: {}
                };
                
                // Extract image metadata
                const img = new Image();
                img.onload = () => {
                    photo.metadata.width = img.width;
                    photo.metadata.height = img.height;
                    photo.metadata.orientation = img.width > img.height ? 'landscape' : 'portrait';
                    photo.metadata.aspectRatio = img.width / img.height;
                    
                    // Analyze image content (simplified)
                    this.analyzeImage(photo, img);
                };
                img.src = e.target.result;
                
                this.state.photos.push(photo);
            };
            reader.readAsDataURL(file);
        });
        
        // After all files are loaded
        setTimeout(() => {
            this.state.selectedPhotos = [...this.state.photos];
            this.renderPhotoGrid();
            this.autoSelectBestPhotos();
        }, 100);
    }

    analyzeImage(photo, img) {
        // Simplified image analysis - in production would use ML
        const canvas = document.createElement('canvas');
        canvas.width = 100;
        canvas.height = 100;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, 100, 100);
        
        const imageData = ctx.getImageData(0, 0, 100, 100);
        const data = imageData.data;
        
        // Calculate average brightness and color
        let brightness = 0;
        let colorfulness = 0;
        for (let i = 0; i < data.length; i += 4) {
            brightness += (data[i] + data[i+1] + data[i+2]) / 3;
            colorfulness += Math.abs(data[i] - data[i+1]) + Math.abs(data[i+1] - data[i+2]);
        }
        
        brightness = brightness / (data.length / 4);
        colorfulness = colorfulness / (data.length / 4);
        
        photo.metadata.brightness = brightness;
        photo.metadata.colorfulness = colorfulness;
        
        // Detect if image likely contains faces (simplified)
        photo.metadata.hasFace = this.detectFace(img);
    }

    detectFace(img) {
        // Simplified face detection - in production would use face-api.js
        // This is a placeholder that returns random for demo
        return Math.random() > 0.5;
    }

    autoSelectBestPhotos() {
        // AI-powered photo selection
        const sorted = [...this.state.photos].sort((a, b) => {
            const scoreA = this.calculatePhotoScore(a);
            const scoreB = this.calculatePhotoScore(b);
            return scoreB - scoreA;
        });
        
        // Select top
