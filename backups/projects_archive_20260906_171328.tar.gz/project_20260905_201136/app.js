// app.js - AI Photo Story Builder

// ===== STATE MANAGEMENT =====
const AppState = {
    photos: [],
    selectedPhotos: [],
    currentProject: null,
    projects: [],
    generatedVariants: [],
    activeVariant: 0,
    settings: {
        gap: 10,
        margin: 20,
        autoGap: true,
        autoMargin: true,
        format: 'instagram',
        template: 'auto',
        style: 'auto'
    },
    editor: {
        selectedPhotoIndex: null,
        isDragging: false,
        dragStartX: 0,
        dragStartY: 0
    },
    user: {
        isPremium: false,
        exportCount: 0
    }
};

// ===== DOM ELEMENTS =====
const elements = {
    dropZone: document.getElementById('dropZone'),
    fileInput: document.getElementById('fileInput'),
    uploadBtn: document.getElementById('uploadBtn'),
    photoGrid: document.getElementById('photoGrid'),
    selectedCount: document.getElementById('selectedCount'),
    generateBtn: document.getElementById('generateBtn'),
    variantsContainer: document.getElementById('variantsContainer'),
    canvasContainer: document.getElementById('canvasContainer'),
    gapSlider: document.getElementById('gapSlider'),
    marginSlider: document.getElementById('marginSlider'),
    gapValue: document.getElementById('gapValue'),
    marginValue: document.getElementById('marginValue'),
    autoGapCheckbox: document.getElementById('autoGap'),
    autoMarginCheckbox: document.getElementById('autoMargin'),
    formatSelect: document.getElementById('formatSelect'),
    templateSelect: document.getElementById('templateSelect'),
    styleSelect: document.getElementById('styleSelect'),
    aiCommandInput: document.getElementById('aiCommandInput'),
    aiCommandBtn: document.getElementById('aiCommandBtn'),
    exportBtn: document.getElementById('exportBtn'),
    exportModal: document.getElementById('exportModal'),
    exportFormat: document.getElementById('exportFormat'),
    confirmExportBtn: document.getElementById('confirmExportBtn'),
    closeModalBtn: document.getElementById('closeModalBtn'),
    historyList: document.getElementById('historyList'),
    loadingOverlay: document.getElementById('loadingOverlay'),
    toast: document.getElementById('toast'),
    smartSelectBtn: document.getElementById('smartSelectBtn'),
    undoBtn: document.getElementById('undoBtn'),
    redoBtn: document.getElementById('redoBtn'),
    zoomInBtn: document.getElementById('zoomInBtn'),
    zoomOutBtn: document.getElementById('zoomOutBtn'),
    rotateBtn: document.getElementById('rotateBtn'),
    flipBtn: document.getElementById('flipBtn'),
    deletePhotoBtn: document.getElementById('deletePhotoBtn'),
    replacePhotoBtn: document.getElementById('replacePhotoBtn'),
    swapBtn: document.getElementById('swapBtn'),
    editModeToggle: document.getElementById('editModeToggle')
};

// ===== TEMPLATES LIBRARY =====
const TEMPLATES = {
    'auto': {
        name: 'AI Auto',
        description: 'AI chooses best layout',
        layouts: []
    },
    'grid-3': {
        name: '3 Grid',
        description: '3 equal vertical photos',
        layouts: [
            { type: 'grid', cols: 1, rows: 3, ratio: '3:4' }
        ]
    },
    'grid-2-1': {
        name: '2+1 Featured',
        description: 'Large top, two below',
        layouts: [
            { type: 'featured', featured: 0, cols: 2, rows: 2 }
        ]
    },
    'story': {
        name: 'Story Sequence',
        description: 'Narrative flow for storytelling',
        layouts: [
            { type: 'story', sequence: [0, 1, 2, 3, 4, 5] }
        ]
    },
    'gallery': {
        name: 'Gallery Style',
        description: 'Museum gallery with breathing room',
        layouts: [
            { type: 'grid', cols: 2, rows: 2, spacing: 'large' }
        ]
    },
    'magazine': {
        name: 'Magazine',
        description: 'Editorial mixed sizes',
        layouts: [
            { type: 'magazine', blocks: ['large', 'small', 'medium', 'small'] }
        ]
    },
    'minimal': {
        name: 'Minimal',
        description: 'Clean, lots of whitespace',
        layouts: [
            { type: 'grid', cols: 1, rows: 2, spacing: 'extra-large' }
        ]
    },
    'dynamic': {
        name: 'Dynamic',
        description: 'Energetic, varied sizes',
        layouts: [
            { type: 'dynamic', pattern: 'zigzag' }
        ]
    }
};

// ===== STYLE PRESETS =====
const STYLE_PRESETS = {
    'auto': { name: 'AI Auto', bg: '#ffffff', accent: '#000000', font: 'Inter' },
    'minimal': { name: 'Minimal', bg: '#ffffff', accent: '#111111', font: 'Helvetica' },
    'air': { name: 'Airy', bg: '#fafafa', accent: '#333333', font: 'Arial' },
    'black': { name: 'Black', bg: '#000000', accent: '#ffffff', font: 'Inter' },
    'brand': { name: 'Brand Colors', bg: '#f0f0f0', accent: '#ff6b6b', font: 'Poppins' }
};

// ===== AI ANALYSIS ENGINE =====
class AIAnalyzer {
    constructor() {
        this.models = {
            faceDetector: null,
            sceneClassifier: null,
            colorAnalyzer: null
        };
    }

    async analyzePhotos(photos) {
        const results = [];
        for (const photo of photos) {
            const analysis = await this.analyzeSinglePhoto(photo);
            results.push(analysis);
        }
        return results;
    }

    async analyzeSinglePhoto(photo) {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0);
                
                const analysis = {
                    id: photo.id,
                    width: img.width,
                    height: img.height,
                    orientation: img.width > img.height ? 'landscape' : img.width < img.height ? 'portrait' : 'square',
                    faces: this.detectFaces(ctx, img.width, img.height),
                    colors: this.extractColors(ctx, img.width, img.height),
                    brightness: this.calculateBrightness(ctx, img.width, img.height),
                    sharpness: this.calculateSharpness(ctx, img.width, img.height),
                    composition: this.analyzeComposition(ctx, img.width, img.height)
                };
