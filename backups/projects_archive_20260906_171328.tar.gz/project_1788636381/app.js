const app = (() => {
  const services = [
    {
      icon: '🚀',
      title: 'Веб-приложения',
      description: 'Создаём масштабируемые SPA и PWA с высокой производительностью и современным стеком.',
      features: ['React / Vue', 'TypeScript', 'Node.js']
    },
    {
      icon: '🎨',
      title: 'UI/UX дизайн',
      description: 'Проектируем интерфейсы, которые продают. От прототипа до дизайн-системы.',
      features: ['Figma', 'Дизайн-системы', 'Анимация']
    },
    {
      icon: '⚙️',
      title: 'API и интеграции',
      description: 'Разрабатываем надёжные REST и GraphQL API, интегрируем внешние сервисы.',
      features: ['REST / GraphQL', 'WebSockets', 'Микросервисы']
    }
  ];

  const renderServices = () => {
    const container = document.getElementById('services-grid');
    if (!container) return;

    container.innerHTML = services.map((service, index) => `
      <div class="service-card" data-aos="fade-up" data-aos-delay="${index * 100}">
        <div class="service-icon">${service.icon}</div>
        <h3>${service.title}</h3>
        <p>${service.description}</p>
        <ul>
          ${service.features.map(feature => `<li>${feature}</li>`).join('')}
        </ul>
      </div>
    `).join('');
  };

  const initScrollAnimations = () => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.service-card, .hero-content, .cta-section').forEach(el => {
      observer.observe(el);
    });
  };

  const initFormHandler = () => {
    const form = document.getElementById('contact-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      
      submitBtn.disabled = true;
      submitBtn.textContent = 'Отправка...';
      
      // Имитация отправки
      setTimeout(() => {
        submitBtn.textContent = '✓ Заявка отправлена!';
        form.reset();
        
        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.textContent = originalText;
        }, 3000);
      }, 1500);
    });
  };

  const initSmoothScroll = () => {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  };

  const initHeaderScroll = () => {
    const header = document.querySelector('.header');
    if (!header) return;

    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    });
  };

  const initMobileMenu = () => {
    const burger = document.querySelector('.burger-menu');
    const nav = document.querySelector('.nav-menu');
    if (!burger || !nav) return;

    burger.addEventListener('click', () => {
      burger.classList.toggle('active');
      nav.classList.toggle('active');
      document.body.classList.toggle('menu-open');
    });
  };

  const init = () => {
    document.addEventListener('DOMContentLoaded', () => {
      renderServices();
      initScrollAnimations();
      initFormHandler();
      initSmoothScroll();
      initHeaderScroll();
      initMobileMenu();
      
      // Добавляем класс для анимации появления
      setTimeout(() => {
        document.querySelector('.hero-content')?.classList.add('visible');
      }, 100);
    });
  };

  return {
    init,
    services
  };
})();

// Автозапуск
app.init();
