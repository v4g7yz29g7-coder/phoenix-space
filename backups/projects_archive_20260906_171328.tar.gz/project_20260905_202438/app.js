document.addEventListener('DOMContentLoaded',function(){
class ProjectStore{
constructor(){this.dbName='evotoFlowDB';this.dbVersion=1;this._init();}
async _init(){this.db=await this._openDB();}
_openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(this.dbName,this.dbVersion);req.onupgradeneeded=(e)=>{const db=e.target.result;if(!db.objectStoreNames.contains('projects')){const store=db.createObjectStore('projects',{keyPath:'id',autoIncrement:true});store.createIndex('date','date',{unique:false});store.createIndex('client','client',{unique:false});}if(!db.objectStoreNames.contains('assets')){const store=db.createObjectStore('assets',{keyPath:'id',autoIncrement:true});store.createIndex('projectId','projectId',{unique:false});store.createIndex('type','type',{unique:false});}if(!db.objectStoreNames.contains('presets')){db.createObjectStore('presets',{keyPath:'name'});}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async saveProject(project){return new Promise((resolve,reject)=>{const tx=this.db.transaction('projects','readwrite');tx.objectStore('projects').put(project);tx.oncomplete=()=>resolve(project.id);tx.onerror=()=>reject(tx.error);});}
async getProject(id){return new Promise((resolve,reject)=>{const tx=this.db.transaction('projects','readonly');const req=tx.objectStore('projects').get(id);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async getAllProjects(){return new Promise((resolve,reject)=>{const tx=this.db.transaction('projects','readonly');const req=tx.objectStore('projects').getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async deleteProject(id){return new Promise((resolve,reject)=>{const tx=this.db.transaction('projects','readwrite');tx.objectStore('projects').delete(id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
async saveAsset(asset){return new Promise((resolve,reject)=>{const tx=this.db.transaction('assets','readwrite');tx.objectStore('assets').put(asset);tx.oncomplete=()=>resolve(asset.id);tx.onerror=()=>reject(tx.error);});}
async getAssetsByProject(projectId){return new Promise((resolve,reject)=>{const tx=this.db.transaction('assets','readonly');const idx=tx.objectStore('assets').index('projectId');const req=idx.getAll(projectId);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
async savePreset(preset){return new Promise((resolve,reject)=>{const tx=this.db.transaction('presets','readwrite');tx.objectStore('presets').put(preset);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
async getPreset(name){return new Promise((resolve,reject)=>{const tx=this.db.transaction('presets','readonly');const req=tx.objectStore('presets').get(name);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
}
class EvotoIntegration{
constructor(){this.apiEndpoint='https://api.evoto.ai/v1';this.apiKey='';}
setApiKey(key){this.apiKey=key;}
async sendForRetouch(projectId,imageIds){const payload={projectId,images:imageIds,action:'retouch'};const response=await fetch(`${this.apiEndpoint}/jobs`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${this.apiKey}`},body:JSON.stringify(payload)});if(!response.ok)throw new Error('Evoto API error');return response.json();}
async getJobStatus(jobId){const response=await fetch(`${this.apiEndpoint}/jobs/${jobId}`,{headers:{'Authorization':`Bearer ${this.apiKey}`}});if(!response.ok)throw new Error('Evoto API error');return response.json();}
}
class SmartSelect{
constructor(){this.model=null;}
async loadModel(){this.model=await tf.loadLayersModel('https://storage.googleapis.com/tfjs-models/tfjs/sentiment_cnn_v1/model.json');}
async scoreImage(imageElement){const tensor=tf.browser.fromPixels(imageElement).resizeNearestNeighbor([224,224]).toFloat().expandDims();const prediction=this.model.predict(tensor);const score=prediction.dataSync()[0];tensor.dispose();return score;}
async selectBest(images,scores){const threshold=0.7;return images.filter((img,i)=>scores[i]>threshold);}
}
class ExportPresets{
constructor(){this.presets={
instagram:{width:1080,height:1080,format:'jpeg',quality:0.9},
vk:{width:1280,height:960,format:'jpeg',quality:0.85},
pdf:{width:2480,height:3508,format:'pdf',quality:1}
};}
async exportImage(canvas,presetName){const preset=this.presets[presetName];if(!preset)throw new Error('Unknown preset');const resized=document.createElement('canvas');resized.width=preset.width;resized.height=preset.height;const ctx=resized.getContext('2d');ctx.drawImage(canvas,0,0,preset.width,preset.height);if(preset.format==='pdf'){return this._exportPDF(resized);}return new Promise((resolve)=>{resized.toBlob(blob=>resolve(blob),`image/${preset.format}`,preset.quality);});}
_exportPDF(canvas){const pdf=new jsPDF('p','px',[canvas.width,canvas.height]);pdf.addImage(canvas.toDataURL('image/jpeg',0.95),'JPEG',0,0,canvas.width,canvas.height);return pdf.output('blob');}
}
class AILayoutEngine{
constructor(){this.rules=[];}
addRule(rule){this.rules.push(rule);}
compose(images,containerWidth,containerHeight){const layout={positions:[],width:containerWidth,height:containerHeight};const cols=Math.ceil(Math.sqrt(images.length));const rows=Math.ceil(images.length/cols);const cellW=containerWidth/cols;const
