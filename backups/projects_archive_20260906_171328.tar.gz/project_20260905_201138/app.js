// app.js - AI Photo Story Builder - Frontend Logic

// ===== STATE MANAGEMENT =====
const AppState = {
    photos: [],
    selectedPhotos: [],
    currentProject: null,
    projects: [],
    currentTemplate: null,
    generatedVariants: [],
    activeVariantIndex: 0,
    gapValue: 10,
    marginValue: 20,
    autoSpacing: true,
    isGenerating: false,
    isExporting: false,
    exportFormat: 'png',
    user: null,
    isPremium: false,
    aiCommandInput: '',
    aiProcessing: false,
    currentView: 'upload', // upload, editor, history, settings
    selectedPlatform: 'instagram',
    smartSelectEnabled: true,
    templates: [
        { id: 'classic-grid', name: 'Классическая сетка', type: 'grid', cols: 3, rows: 3, description: 'Ровная сетка 3x3' },
        { id: 'story-flow', name: 'Сторителлинг', type: 'story', description: 'История: эмоция, детали, общий план' },
        { id: 'magazine', name: 'Журнальный стиль', type: 'magazine', description: 'Крупные и мелкие кадры вперемешку' },
        { id: 'minimal', name: 'Минимализм', type: 'minimal', description: 'Много воздуха, чистые линии' },
        { id: 'dynamic', name: 'Динамичный', type: 'dynamic', description: 'Смелые ракурсы, крупные планы' },
        { id: 'elegant', name: 'Элегантный', type: 'elegant', description: 'Плавные переходы, мягкие тона' },
        { id: 'gallery', name: 'Галерея', type: 'gallery', description: 'Для портфолио, много отступов' },
        { id: 'wedding', name: 'Свадебная история', type: 'wedding', description: 'Драматургия свадебной съёмки' }
    ],
    exportPresets: {
        instagram: { width: 1080, height: 1080, format: 'png' },
        vk: { width: 1200, height: 630, format: 'png' },
        pdf: { format: 'pdf', quality: 'high' }
    }
};

// ===== DOM ELEMENTS =====
const elements = {
    uploadZone: document.getElementById('upload-zone'),
    fileInput: document.getElementById('file-input'),
    photoGrid: document.getElementById('photo-grid'),
    selectedCount: document.getElementById('selected-count'),
    templateGrid: document.getElementById('template-grid'),
    generateBtn: document.getElementById('generate-btn'),
    variantsContainer: document.getElementById('variants-container'),
    editorCanvas: document.getElementById('editor-canvas'),
    gapSlider: document.getElementById('gap-slider'),
    marginSlider: document.getElementById('margin-slider'),
    gapValueDisplay: document.getElementById('gap-value'),
    marginValueDisplay: document.getElementById('margin-value'),
    autoSpacingToggle: document.getElementById('auto-spacing'),
    exportBtn: document.getElementById('export-btn'),
    exportFormatSelect: document.getElementById('export-format'),
    aiCommandInput: document.getElementById('ai-command-input'),
    aiCommandBtn: document.getElementById('ai-command-btn'),
    projectHistory: document.getElementById('project-history'),
    viewUpload: document.getElementById('view-upload'),
    viewEditor: document.getElementById('view-editor'),
    viewHistory: document.getElementById('view-history'),
    smartSelectToggle: document.getElementById('smart-select'),
    platformSelect: document.getElementById('platform-select'),
    loadingOverlay: document.getElementById('loading-overlay'),
    toastContainer: document.getElementById('toast-container')
};

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

function initApp() {
    // Load saved projects from localStorage
    loadProjects();
    
    // Setup event listeners
    setupEventListeners();
    
    // Render initial views
    renderTemplates();
    renderProjectHistory();
    
    // Check for saved session
    checkSession();
    
    // Initialize sliders
    updateSliderDisplays();
    
    // Show upload view by default
    switchView('upload');
}

function setupEventListeners() {
    // Upload zone events
    elements.uploadZone.addEventListener('click', () => elements.fileInput.click());
    elements.uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        elements.uploadZone.classList.add('dragover');
    });
    elements.uploadZone.addEventListener('dragleave', () => {
        elements.uploadZone.classList.remove('dragover');
    });
    elements.uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        elements.uploadZone.classList.remove('dragover');
        handleFiles(e.dataTransfer.files);
    });
    elements.fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });
    
    // Template selection
    elements.templateGrid.addEventListener('click', (e) => {
        const templateCard = e.target.closest('.template-card');
        if (templateCard) {
            selectTemplate(templateCard.dataset.id);
        }
    });
    
    // Generate button
    elements.generateBtn.addEventListener('click', generateVariants);
    
    // Sliders
    elements.gapSlider.addEventListener('input', (e) => {
        AppState.gapValue = parseInt(e.target.value);
        AppState.autoSpacing = false;
        elements.autoSpacingToggle.checked = false;
        updateSliderDisplays();
        if (AppState.currentProject) {
            updateEditorPreview();
        }
    });
    
    elements.marginSlider.addEventListener('input', (e) => {
        AppState.marginValue = parseInt(e.target.value);
        AppState.autoSpacing = false;
        elements.autoSpacingToggle.checked = false;
        updateSliderDisplays();
        if (AppState.currentProject) {
            updateEditorPreview();
        }
    });
    
    elements.autoSpacingToggle.addEventListener('change', (e) => {
        AppState.autoSpacing = e.target.checked;
        if (AppState.autoSpacing) {
            calculateAutoSpacing();
        }
    });
    
    // Export
    elements.exportBtn.addEventListener('click', exportProject);
    elements.exportFormatSelect.addEventListener('change', (e) => {
        AppState.exportFormat = e.target.value;
    });
    
    // AI Command
    elements.aiCommandBtn.addEventListener('click', processAICommand);
    elements.aiCommandInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            processAICommand();
        }
    });
    
    // View switching
    elements.viewUpload.addEventListener('click', () => switchView
