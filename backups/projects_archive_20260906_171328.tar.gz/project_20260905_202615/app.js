document.addEventListener('DOMContentLoaded',function(){
  const state={
    projects:JSON.parse(localStorage.getItem('evoto_projects')||'[]'),
    currentProject:null,
    selectedImages:new Set(),
    aiSuggestions:[],
    presets:{instagram:{width:1080,height:1080,format:'jpg'},vk:{width:1280,height:720,format:'jpg'},pdf:{width:2480,height:3508,format:'pdf'}}
  };
  const db={
    save(){localStorage.setItem('evoto_projects',JSON.stringify(state.projects))},
    find(id){return state.projects.find(p=>p.id===id)},
    upsert(project){const i=state.projects.findIndex(p=>p.id===project.id);if(i>-1)state.projects[i]=project;else state.projects.push(project);this.save();return project},
    remove(id){state.projects=state.projects.filter(p=>p.id!==id);this.save()}
  };
  const evotoAPI={
    async sendForRetouch(projectId,imageIds){
      const project=db.find(projectId);
      if(!project)throw new Error('Project not found');
      const payload={projectId,images:imageIds.map(id=>project.images.find(img=>img.id===id)).filter(Boolean)};
      console.log('Evoto retouch request:',payload);
      return {status:'queued',batchId:Date.now()};
    },
    async getRetouchStatus(batchId){
      return {batchId,status:'completed',progress:100};
    }
  };
  const aiEngine={
    analyzeComposition(imageData){
      const brightness=imageData.reduce((a,p)=>a+p.brightness,0)/imageData.length;
      const sharpness=imageData.reduce((a,p)=>a+p.sharpness,0)/imageData.length;
      const faces=imageData.filter(p=>p.hasFace).length;
      return {score:(brightness*0.4+sharpness*0.3+Math.min(faces/imageData.length,1)*0.3)*100};
    },
    smartSelect(projectId,limit=10){
      const project=db.find(projectId);
      if(!project)return[];
      const scored=project.images.map(img=>({...img,score:this.analyzeComposition([img]).score}));
      scored.sort((a,b)=>b.score-a.score);
      return scored.slice(0,limit).map(img=>img.id);
    },
    suggestLayout(projectId){
      const project=db.find(projectId);
      if(!project)return{type:'grid',cols:3,rows:Math.ceil(project.images.length/3)};
      const count=project.images.length;
      if(count<=3)return{type:'hero',cols:1,rows:count};
      if(count<=6)return{type:'grid',cols:2,rows:Math.ceil(count/2)};
      return{type:'masonry',cols:3,rows:Math.ceil(count/3)};
    }
  };
  const exportManager={
    async exportProject(projectId,presetName){
      const project=db.find(projectId);
      if(!project)throw new Error('Project not found');
      const preset=state.presets[presetName];
      if(!preset)throw new Error('Preset not found');
      const layout=aiEngine.suggestLayout(projectId);
      const canvas=document.createElement('canvas');
      canvas.width=preset.width;
      canvas.height=preset.height;
      const ctx=canvas.getContext('2d');
      ctx.fillStyle='#fff';
      ctx.fillRect(0,0,canvas.width,canvas.height);
      const imgSize=Math.min(canvas.width/layout.cols,canvas.height/layout.rows);
      project.images.forEach((img,index)=>{
        const col=index%layout.cols;
        const row=Math.floor(index/layout.cols);
        const x=col*imgSize;
        const y=row*imgSize;
        ctx.fillStyle='#eee';
        ctx.fillRect(x,y,imgSize-10,imgSize-10);
        ctx.fillStyle='#333';
        ctx.font='14px Arial';
        ctx.fillText(img.name||`Image ${index+1}`,x+10,y+20);
      });
      const link=document.createElement('a');
      link.download=`${project.name}_${presetName}.${preset.format==='pdf'?'pdf':'jpg'}`;
      link.href=canvas.toDataURL(`image/${preset.format==='pdf'?'jpeg':preset.format}`);
      link.click();
      return{success:true,format:preset.format,size:`${preset.width}x${preset.height}`};
    },
    generatePDF(projectId){
      const project=db.find(projectId);
      if(!project)return null;
      const layout=aiEngine.suggestLayout(projectId);
      const pageWidth=2480;
      const pageHeight=3508;
      const pages=[];
      const imagesPerPage=layout.cols*layout.rows;
      for(let i=0;i<project.images.length;i+=imagesPerPage){
        const pageImages=project.images.slice(i,i+imagesPerPage);
        pages.push({page:pages.length+1,images:pageImages,layout});
      }
      return{projectId,pages,pageSize:{width:pageWidth,height:pageHeight}};
    }
  };
  const ui={
    renderProjects(){
      const container=document.getElementById('project-list')||this.createContainer('project-list');
      container.innerHTML='';
      state.projects.forEach(project=>{
        const card=document.createElement('div');
        card.className='project-card';
        card.innerHTML=`<h3>${project.name}</h3><p>${project.images.length} images</p><button data-action="open" data-id="${project.id}">Open</button><button data-action="delete" data-id="${project.id}">Delete</button>`;
        container.appendChild(card);
      });
    },
    createContainer(id){
      const div=document.createElement('div');
      div.id=id;
      document.body.appendChild(div);
      return div;
    },
    showSmartSelect(projectId){
      const suggestions=aiEngine.smartSelect(projectId);
      state.aiSuggestions=suggestions;
      const container=document.getElementById('ai-suggestions')||this.createContainer('ai-suggestions');
      container.innerHTML='<h3>AI Smart Select</h3>';
      suggestions.forEach(imgId=>{
        const btn=document.createElement('button');
        btn.textContent=`Select ${imgId}`;
        btn.onclick=()=>{
          if(state.selectedImages.has(imgId)){
            state.selectedImages.delete(imgId);
            btn.style.background='';
          }else{
            state
