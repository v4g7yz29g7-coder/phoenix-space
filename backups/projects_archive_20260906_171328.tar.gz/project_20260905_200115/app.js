// app.js - AI Photo Story Builder

class PhotoStoryBuilder {
    constructor() {
        this.state = {
            photos: [],
            selectedPhotos: [],
            currentLayout: null,
            layouts: [],
            gapSize: 10,
            marginSize: 20,
            autoMode: true,
            format: 'instagram',
            projectHistory: [],
            currentProject: null,
            isGenerating: false,
            generatedVariants: []
        };

        this.elements = {};
        this.aiAgent = new AIAgent();
        this.layoutEngine = new LayoutEngine();
        this.photoAnalyzer = new PhotoAnalyzer();
        this.storyTeller = new StoryTeller();
        
        this.init();
    }

    init() {
        this.cacheElements();
        this.bindEvents();
        this.loadProjectHistory();
        this.initDragAndDrop();
        this.initSliders();
        this.initTemplateLibrary();
        this.initAICommands();
    }

    cacheElements() {
        this.elements = {
            uploadZone: document.getElementById('upload-zone'),
            photoGrid: document.getElementById('photo-grid'),
            canvas: document.getElementById('canvas'),
            generateBtn: document.getElementById('generate-btn'),
            layoutSelector: document.getElementById('layout-selector'),
            gapSlider: document.getElementById('gap-slider'),
            marginSlider: document.getElementById('margin-slider'),
            autoModeToggle: document.getElementById('auto-mode'),
            formatSelector: document.getElementById('format-selector'),
            variantCarousel: document.getElementById('variant-carousel'),
            aiCommandInput: document.getElementById('ai-command-input'),
            aiCommandBtn: document.getElementById('ai-command-btn'),
            exportBtn: document.getElementById('export-btn'),
            projectList: document.getElementById('project-list'),
            smartSelectBtn: document.getElementById('smart-select-btn'),
            presetSelector: document.getElementById('preset-selector'),
            storyModeBtn: document.getElementById('story-mode-btn')
        };
    }

    bindEvents() {
        // Upload handling
        this.elements.uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.elements.uploadZone.classList.add('dragover');
        });

        this.elements.uploadZone.addEventListener('dragleave', () => {
            this.elements.uploadZone.classList.remove('dragover');
        });

        this.elements.uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            this.handleFileUpload(e.dataTransfer.files);
        });

        // Generate button
        this.elements.generateBtn.addEventListener('click', () => this.generateLayouts());

        // Slider events
        this.elements.gapSlider.addEventListener('input', (e) => {
            this.state.gapSize = parseInt(e.target.value);
            if (!this.state.autoMode) {
                this.updateCanvas();
            }
        });

        this.elements.marginSlider.addEventListener('input', (e) => {
            this.state.marginSize = parseInt(e.target.value);
            if (!this.state.autoMode) {
                this.updateCanvas();
            }
        });

        // Auto mode toggle
        this.elements.autoModeToggle.addEventListener('change', (e) => {
            this.state.autoMode = e.target.checked;
            this.elements.gapSlider.disabled = this.state.autoMode;
            this.elements.marginSlider.disabled = this.state.autoMode;
            if (this.state.autoMode) {
                this.autoOptimizeSpacing();
            }
        });

        // Format selector
        this.elements.formatSelector.addEventListener('change', (e) => {
            this.state.format = e.target.value;
            this.updateCanvasDimensions();
        });

        // AI Command
        this.elements.aiCommandBtn.addEventListener('click', () => this.processAICommand());
        this.elements.aiCommandInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.processAICommand();
            }
        });

        // Export
        this.elements.exportBtn.addEventListener('click', () => this.exportProject());

        // Smart select
        this.elements.smartSelectBtn.addEventListener('click', () => this.smartSelectPhotos());

        // Story mode
        this.elements.storyModeBtn.addEventListener('click', () => this.enableStoryMode());

        // Preset selector
        this.elements.presetSelector.addEventListener('change', (e) => {
            this.applyPreset(e.target.value);
        });
    }

    handleFileUpload(files) {
        const imageFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
        
        imageFiles.forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const photo = {
                    id: Date.now() + Math.random(),
                    src: e.target.result,
                    name: file.name,
                    width: 0,
                    height: 0,
                    orientation: null,
                    faces: [],
                    dominantColors: [],
                    quality: 0,
                    isDuplicate: false
                };

                const img = new Image();
                img.onload = () => {
                    photo.width = img.width;
                    photo.height = img.height;
                    photo.orientation = img.width > img.height ? 'landscape' : 
                                       img.height > img.width ? 'portrait' : 'square';
                    
                    this.state.photos.push(photo);
                    this.displayPhoto(photo);
                    this.analyzePhoto(photo);
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        });
    }

    displayPhoto(photo) {
        const photoElement = document.createElement('div');
        photoElement.className = 'photo-item';
        photoElement.id = `photo-${photo.id}`;
        photoElement.innerHTML = `
            <img src="${photo.src}" alt="${photo.name}">
            <div class="photo-overlay">
                <span class="photo-quality">${Math.round(photo.quality * 100)}%</span>
                <button class="remove-photo" onclick="builder.removePhoto(${photo.id})">×</button>
            </div>
        `;
        this.elements.photoGrid.appendChild(photoElement);
    }

    removePhoto(photoId) {
        this.state.photos = this.state.photos.filter(p => p.id !== photoId);
        document.getElementById(`photo-${photoId}`).remove();
    }

    async analyzePhoto(photo) {
        const analysis = await this.photoAnalyzer.analyze(photo);
        photo.faces = analysis.faces;
        photo.dominantColors = analysis.colors;
        photo.quality = analysis.quality;
        photo.isDuplicate = analysis.isDuplicate;
        
        // Update photo display with analysis results
        const photoElement = document.getElementById(`photo-${photo.id}`);
        if (photoElement) {
            const qualityBadge = photoElement.querySelector('.photo-quality');
            if (qualityBadge) {
                qualityBadge.textContent = `${Math.round(photo.quality * 100)}%`;
            }
        }
    }

    async generateLayouts() {
        if (this.state.photos.length ===
