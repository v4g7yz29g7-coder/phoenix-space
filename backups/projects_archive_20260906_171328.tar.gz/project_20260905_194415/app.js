const app = (() => {
  const state = {
    isModalOpen: false,
    isFormSubmitting: false,
    formData: {
      name: '',
      phone: '',
      comment: ''
    }
  };

  const elements = {
    modal: null,
    modalOverlay: null,
    modalCloseBtn: null,
    form: null,
    formName: null,
    formPhone: null,
    formComment: null,
    formSubmitBtn: null,
    formError: null,
    formSuccess: null,
    ctaButtons: [],
    serviceCards: []
  };

  const init = () => {
    cacheDom();
    bindEvents();
    setupServiceCardInteractions();
  };

  const cacheDom = () => {
    elements.modal = document.getElementById('modal');
    elements.modalOverlay = document.querySelector('.modal-overlay');
    elements.modalCloseBtn = document.querySelector('.modal-close');
    elements.form = document.getElementById('request-form');
    elements.formName = document.getElementById('name');
    elements.formPhone = document.getElementById('phone');
    elements.formComment = document.getElementById('comment');
    elements.formSubmitBtn = document.querySelector('.form-submit');
    elements.formError = document.querySelector('.form-error');
    elements.formSuccess = document.querySelector('.form-success');
    elements.ctaButtons = document.querySelectorAll('[data-action="open-modal"]');
    elements.serviceCards = document.querySelectorAll('.service-card');
  };

  const bindEvents = () => {
    elements.ctaButtons.forEach(btn => {
      btn.addEventListener('click', openModal);
    });

    elements.modalCloseBtn.addEventListener('click', closeModal);
    elements.modalOverlay.addEventListener('click', (e) => {
      if (e.target === elements.modalOverlay) closeModal();
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && state.isModalOpen) closeModal();
    });

    elements.form.addEventListener('submit', handleFormSubmit);

    elements.formName.addEventListener('input', (e) => {
      state.formData.name = e.target.value;
      clearFormMessages();
    });

    elements.formPhone.addEventListener('input', (e) => {
      state.formData.phone = e.target.value;
      clearFormMessages();
    });

    elements.formComment.addEventListener('input', (e) => {
      state.formData.comment = e.target.value;
      clearFormMessages();
    });
  };

  const setupServiceCardInteractions = () => {
    elements.serviceCards.forEach(card => {
      card.addEventListener('mouseenter', () => {
        card.style.transform = 'translateY(-8px)';
        card.style.boxShadow = '0 12px 30px rgba(0, 0, 0, 0.3)';
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = 'translateY(0)';
        card.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.2)';
      });

      const cardBtn = card.querySelector('.card-btn');
      if (cardBtn) {
        cardBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          const serviceName = card.querySelector('h3').textContent;
          state.formData.comment = `Услуга: ${serviceName}`;
          if (elements.formComment) {
            elements.formComment.value = state.formData.comment;
          }
          openModal();
        });
      }
    });
  };

  const openModal = () => {
    state.isModalOpen = true;
    elements.modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    setTimeout(() => {
      if (elements.formName) elements.formName.focus();
    }, 100);
  };

  const closeModal = () => {
    state.isModalOpen = false;
    elements.modal.classList.remove('active');
    document.body.style.overflow = '';
    resetForm();
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    
    if (state.isFormSubmitting) return;

    const validation = validateForm();
    if (!validation.isValid) {
      showFormError(validation.errors.join(' '));
      return;
    }

    state.isFormSubmitting = true;
    elements.formSubmitBtn.disabled = true;
    elements.formSubmitBtn.textContent = 'Отправка...';

    // Имитация отправки на сервер
    setTimeout(() => {
      state.isFormSubmitting = false;
      elements.formSubmitBtn.disabled = false;
      elements.formSubmitBtn.textContent = 'Отправить заявку';
      
      showFormSuccess();
      resetForm();
      
      setTimeout(() => {
        closeModal();
      }, 2000);
    }, 1500);
  };

  const validateForm = () => {
    const errors = [];
    
    if (!state.formData.name || state.formData.name.trim().length < 2) {
      errors.push('Введите корректное имя');
      elements.formName.classList.add('error');
    } else {
      elements.formName.classList.remove('error');
    }

    const phoneRegex = /^(\+7|8)?[\s\-]?\(?[0-9]{3}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$/;
    if (!state.formData.phone || !phoneRegex.test(state.formData.phone.trim())) {
      errors.push('Введите корректный номер телефона');
      elements.formPhone.classList.add('error');
    } else {
      elements.formPhone.classList.remove('error');
    }

    return { isValid: errors.length === 0, errors };
  };

  const showFormError = (message) => {
    if (elements.formError) {
      elements.formError.textContent = message;
      elements.formError.style.display = 'block';
    }
    if (elements.formSuccess) {
      elements.formSuccess.style.display = 'none';
    }
  };

  const showFormSuccess = () => {
    if (elements.formError) {
      elements.formError.style.display = 'none';
    }
    if (elements.formSuccess) {
      elements.formSuccess.textContent = 'Заявка успешно отправлена! Мы свяжемся с вами в ближайшее время.';
      elements.formSuccess.style.display = 'block';
    }
  };

  const clearFormMessages = () => {
    if (elements.formError) {
      elements.formError.style.display = 'none';
    }
    if (elements.formSuccess) {
      elements.formSuccess.style.display = 'none';
    }
  };

  const resetForm = () => {
    state.formData = {
      name: '',
      phone: '',
      comment: ''
    };
    
    if (elements.form) {
      elements.form.reset();
    }
    
    if (elements.formName) elements.formName.classList.remove('error');
    if (elements.formPhone) elements.formPhone.classList.remove('error');
