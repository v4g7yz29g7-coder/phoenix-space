// app.js - AI Photo Story Builder

// ===== STATE MANAGEMENT =====
const state = {
    photos: [],
    selectedPhotos: [],
    currentProject: null,
    projects: [],
    templates: [],
    currentTemplate: null,
    generatedVariants: [],
    activeVariant: 0,
    gapSize: 10,
    marginSize: 20,
    autoSpacing: true,
    exportFormat: 'png',
    isGenerating: false,
    user: null,
    isPremium: false,
    history: []
};

// ===== DOM ELEMENTS =====
const elements = {
    dropZone: document.getElementById('dropZone'),
    fileInput: document.getElementById('fileInput'),
    photoGrid: document.getElementById('photoGrid'),
    templateGrid: document.getElementById('templateGrid'),
    canvasContainer: document.getElementById('canvasContainer'),
    gapSlider: document.getElementById('gapSlider'),
    marginSlider: document.getElementById('marginSlider'),
    autoSpacingToggle: document.getElementById('autoSpacingToggle'),
    generateBtn: document.getElementById('generateBtn'),
    variantCarousel: document.getElementById('variantCarousel'),
    exportBtn: document.getElementById('exportBtn'),
    aiCommandInput: document.getElementById('aiCommandInput'),
    aiCommandBtn: document.getElementById('aiCommandBtn'),
    projectList: document.getElementById('projectList'),
    uploadProgress: document.getElementById('uploadProgress'),
    loadingOverlay: document.getElementById('loadingOverlay'),
    toast: document.getElementById('toast')
};

// ===== TEMPLATE DEFINITIONS =====
const templateDefinitions = [
    {
        id: 'classic-grid',
        name: 'Классическая сетка',
        description: 'Равномерная сетка для галерейной подачи',
        layout: 'grid',
        columns: 3,
        rows: 3,
        style: 'minimal'
    },
    {
        id: 'story-teller',
        name: 'Сторителлинг',
        description: 'История: эмоция → детали → общий план',
        layout: 'story',
        sequence: ['close-up', 'detail', 'wide', 'emotion', 'detail', 'wide', 'emotion', 'close-up', 'wide'],
        style: 'editorial'
    },
    {
        id: 'dynamic-mix',
        name: 'Динамичный',
        description: 'Чередование крупных и общих планов',
        layout: 'dynamic',
        pattern: ['large', 'small', 'small', 'large', 'small', 'small', 'large'],
        style: 'bold'
    },
    {
        id: 'air-minimal',
        name: 'Воздушный минимализм',
        description: 'Большие отступы, чистый фон',
        layout: 'grid',
        columns: 2,
        rows: 2,
        style: 'airy',
        gapMultiplier: 3,
        marginMultiplier: 2
    },
    {
        id: 'editorial-spread',
        name: 'Журнальный разворот',
        description: 'Крупные фото с акцентами',
        layout: 'editorial',
        pattern: ['hero', 'support', 'support', 'hero', 'support', 'support'],
        style: 'editorial'
    },
    {
        id: 'wedding-story',
        name: 'Свадебная история',
        description: 'Драматургия: подготовка → церемония → праздник',
        layout: 'wedding',
        sequence: ['preparation', 'emotion', 'ceremony', 'details', 'guests', 'celebration', 'finale'],
        style: 'romantic'
    }
];

// ===== AI ANALYSIS ENGINE =====
class PhotoAnalyzer {
    constructor() {
        this.faceDetectionModel = null;
        this.colorAnalyzer = null;
    }

    async analyzePhoto(photo) {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                const analysis = {
                    orientation: img.width > img.height ? 'landscape' : img.height > img.width ? 'portrait' : 'square',
                    aspectRatio: img.width / img.height,
                    brightness: this.analyzeBrightness(img),
                    colorPalette: this.analyzeColors(img),
                    hasFaces: false,
                    faceCount: 0,
                    sharpness: 0,
                    composition: 'unknown'
                };

                // Simulate face detection (in production, use TensorFlow.js or similar)
                if (Math.random() > 0.5) {
                    analysis.hasFaces = true;
                    analysis.faceCount = Math.floor(Math.random() * 4) + 1;
                }

                // Analyze composition based on brightness distribution
                analysis.composition = this.analyzeComposition(img);

                photo.analysis = analysis;
                resolve(analysis);
            };
            img.src = URL.createObjectURL(photo);
        });
    }

    analyzeBrightness(img) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 50;
        canvas.height = 50;
        ctx.drawImage(img, 0, 0, 50, 50);
        const data = ctx.getImageData(0, 0, 50, 50).data;
        let sum = 0;
        for (let i = 0; i < data.length; i += 4) {
            sum += (data[i] + data[i + 1] + data[i + 2]) / 3;
        }
        return sum / (50 * 50);
    }

    analyzeColors(img) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 20;
        canvas.height = 20;
        ctx.drawImage(img, 0, 0, 20, 20);
        const data = ctx.getImageData(0, 0, 20, 20).data;
        const colors = [];
        for (let i = 0; i < data.length; i += 4) {
            colors.push(`rgb(${data[i]},${data[i + 1]},${data[i + 2]})`);
        }
        return colors;
    }

    analyzeComposition(img) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 100;
        canvas.height = 100;
        ctx.drawImage(img, 0, 0, 100, 100);
        const data = ctx.getImageData(0, 0, 100, 100).data;
        
        // Analyze brightness distribution
        const quadrants = [0, 0, 0, 0];
        for (let y = 0; y < 100; y++) {
            for (let x = 0; x < 100; x++) {
                const idx =
