document.addEventListener('DOMContentLoaded', function() {
  console.log('Приложение загружено');
  // Здесь будет ваша логика
});
