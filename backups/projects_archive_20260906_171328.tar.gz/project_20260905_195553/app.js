// app.js - AI Photo Story Builder

class PhotoStoryBuilder {
    constructor() {
        this.state = {
            photos: [],
            selectedPhotos: [],
            currentLayout: null,
            layouts: [],
            spacing: 10,
            margin: 20,
            autoMode: true,
            format: 'instagram',
            projectHistory: [],
            currentProject: null,
            isGenerating: false,
            generatedVariants: [],
            activeVariant: 0
        };

        this.elements = {};
        this.aiEngine = new AIEngine();
        this.layoutEngine = new LayoutEngine();
        this.exportEngine = new ExportEngine();
        
        this.init();
    }

    async init() {
        this.cacheElements();
        this.bindEvents();
        this.loadProjectHistory();
        this.initDragAndDrop();
        this.initSliders();
        this.initTemplateLibrary();
        this.initAICommands();
        this.initExportPresets();
        this.render();
    }

    cacheElements() {
        this.elements = {
            uploadZone: document.getElementById('upload-zone'),
            photoGrid: document.getElementById('photo-grid'),
            canvas: document.getElementById('canvas'),
            layoutSelector: document.getElementById('layout-selector'),
            spacingSlider: document.getElementById('spacing-slider'),
            marginSlider: document.getElementById('margin-slider'),
            autoSpacingCheckbox: document.getElementById('auto-spacing'),
            autoMarginCheckbox: document.getElementById('auto-margin'),
            generateBtn: document.getElementById('generate-btn'),
            variantCarousel: document.getElementById('variant-carousel'),
            aiCommandInput: document.getElementById('ai-command-input'),
            aiCommandBtn: document.getElementById('ai-command-btn'),
            exportBtn: document.getElementById('export-btn'),
            formatSelector: document.getElementById('format-selector'),
            projectList: document.getElementById('project-list'),
            loadingOverlay: document.getElementById('loading-overlay'),
            toast: document.getElementById('toast')
        };
    }

    bindEvents() {
        // Upload events
        this.elements.uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.elements.uploadZone.classList.add('dragover');
        });

        this.elements.uploadZone.addEventListener('dragleave', () => {
            this.elements.uploadZone.classList.remove('dragover');
        });

        this.elements.uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            this.elements.uploadZone.classList.remove('dragover');
            this.handleFiles(e.dataTransfer.files);
        });

        // Click to upload
        this.elements.uploadZone.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.multiple = true;
            input.onchange = (e) => this.handleFiles(e.target.files);
            input.click();
        });

        // Generate button
        this.elements.generateBtn.addEventListener('click', () => this.generateVariants());

        // AI command
        this.elements.aiCommandBtn.addEventListener('click', () => this.processAICommand());
        this.elements.aiCommandInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.processAICommand();
        });

        // Export
        this.elements.exportBtn.addEventListener('click', () => this.exportCurrentVariant());

        // Format change
        this.elements.formatSelector.addEventListener('change', (e) => {
            this.state.format = e.target.value;
            this.updateCanvasSize();
        });

        // Slider events
        this.elements.spacingSlider.addEventListener('input', (e) => {
            this.state.spacing = parseInt(e.target.value);
            this.state.autoMode = false;
            this.elements.autoSpacingCheckbox.checked = false;
            this.renderCurrentLayout();
        });

        this.elements.marginSlider.addEventListener('input', (e) => {
            this.state.margin = parseInt(e.target.value);
            this.state.autoMode = false;
            this.elements.autoMarginCheckbox.checked = false;
            this.renderCurrentLayout();
        });

        // Auto mode checkboxes
        this.elements.autoSpacingCheckbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                this.state.autoMode = true;
                this.elements.autoMarginCheckbox.checked = true;
                this.applyAutoSpacing();
            }
        });

        this.elements.autoMarginCheckbox.addEventListener('change', (e) => {
            if (e.target.checked) {
                this.state.autoMode = true;
                this.elements.autoSpacingCheckbox.checked = true;
                this.applyAutoSpacing();
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Delete' && this.state.selectedPhotos.length > 0) {
                this.removeSelectedPhotos();
            }
            if (e.ctrlKey && e.key === 'z') {
                this.undoLastAction();
            }
        });
    }

    handleFiles(files) {
        const imageFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
        
        if (imageFiles.length === 0) {
            this.showToast('Пожалуйста, выберите изображения', 'error');
            return;
        }

        this.showLoading('Анализируем фотографии...');
        
        // Process each file
        const promises = imageFiles.map(file => this.processImage(file));
        
        Promise.all(promises).then((processedImages) => {
            this.state.photos = [...this.state.photos, ...processedImages];
            this.state.selectedPhotos = [...this.state.photos];
            
            // AI analysis
            this.aiEngine.analyzePhotos(this.state.photos).then((analysis) => {
                this.state.photoAnalysis = analysis;
                this.autoSelectBestPhotos();
                this.renderPhotoGrid();
                this.hideLoading();
                this.showToast(`Загружено ${processedImages.length} фотографий`, 'success');
            });
        }).catch((error) => {
            console.error('Error processing images:', error);
            this.hideLoading();
            this.showToast('Ошибка при загрузке изображений', 'error');
        });
    }

    processImage(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    resolve({
                        id: Date.now() + Math.random(),
                        file: file,
                        dataUrl: e.target.result,
                        width: img.width,
                        height: img.height,
                        orientation: img.width > img.height ? 'landscape' : 'portrait',
                        faces: [],
                        colors: [],
                        selected: true
                    });
                };
                img.src = e.target.result;
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    autoSelectBestPhotos() {
        //
