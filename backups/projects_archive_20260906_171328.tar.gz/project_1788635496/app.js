const services = [
  {
    icon: '🚀',
    title: 'Веб-разработка',
    description: 'Создаём быстрые и адаптивные сайты под ключ: от лендинга до сложных веб-приложений.'
  },
  {
    icon: '📱',
    title: 'Мобильные приложения',
    description: 'Разрабатываем нативные и кроссплатформенные приложения для iOS и Android.'
  },
  {
    icon: '🎨',
    title: 'UI/UX дизайн',
    description: 'Проектируем интуитивные интерфейсы, которые нравятся пользователям и повышают конверсию.'
  }
];

const app = document.getElementById('app');

app.innerHTML = `
  <header class="hero">
    <h1>Студия разработки <span class="accent">CodeCraft</span></h1>
    <p class="subtitle">Создаём цифровые продукты, которые двигают бизнес вперёд</p>
    <button class="cta-btn" id="ctaBtn">Оставить заявку</button>
  </header>

  <section class="services">
    ${services.map((service, index) => `
      <div class="service-card" style="animation-delay: ${index * 0.15}s">
        <div class="service-icon">${service.icon}</div>
        <h3>${service.title}</h3>
        <p>${service.description}</p>
      </div>
    `).join('')}
  </section>

  <div class="modal-overlay" id="modalOverlay">
    <div class="modal">
      <button class="modal-close" id="modalClose">×</button>
      <h2>Оставьте заявку</h2>
      <form id="contactForm">
        <input type="text" placeholder="Ваше имя" required>
        <input type="email" placeholder="Email" required>
        <textarea placeholder="Опишите ваш проект" rows="4" required></textarea>
        <button type="submit" class="submit-btn">Отправить</button>
      </form>
    </div>
  </div>
`;

const ctaBtn = document.getElementById('ctaBtn');
const modalOverlay = document.getElementById('modalOverlay');
const modalClose = document.getElementById('modalClose');
const contactForm = document.getElementById('contactForm');

ctaBtn.addEventListener('click', () => {
  modalOverlay.classList.add('active');
  document.body.style.overflow = 'hidden';
});

modalClose.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) closeModal();
});

function closeModal() {
  modalOverlay.classList.remove('active');
  document.body.style.overflow = '';
}

contactForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const formData = new FormData(contactForm);
  const data = Object.fromEntries(formData.entries());
  
  // Имитация отправки
  const submitBtn = contactForm.querySelector('.submit-btn');
  submitBtn.textContent = 'Отправка...';
  submitBtn.disabled = true;
  
  setTimeout(() => {
    alert(`Спасибо, ${data[0]}! Мы свяжемся с вами в ближайшее время.`);
    contactForm.reset();
    submitBtn.textContent = 'Отправить';
    submitBtn.disabled = false;
    closeModal();
  }, 1500);
});

// Плавное появление карточек при скролле
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.service-card').forEach(card => {
  card.style.opacity = '0';
  card.style.transform = 'translateY(30px)';
  card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(card);
});
