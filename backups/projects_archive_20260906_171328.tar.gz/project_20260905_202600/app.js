document.addEventListener('DOMContentLoaded',function(){
  const state={
    projects:JSON.parse(localStorage.getItem('evoto_projects')||'[]'),
    currentProject:null,
    selectedImages:new Set(),
    aiSuggestions:[],
    presets:{instagram:{width:1080,height:1080,format:'jpg'},vk:{width:1080,height:1350,format:'jpg'},pdf:{width:2480,height:3508,format:'pdf'}}
  };
  const evotoBridge={
    connect:()=>new Promise(res=>setTimeout(()=>res({status:'connected',apiVersion:'2.1'}),500)),
    sendForRetouch:(images,settings)=>new Promise(res=>setTimeout(()=>res({jobId:'ev_'+Date.now(),images:images.map(i=>({...i,retouched:true}))}),1000)),
    getRetouched:(jobId)=>state.projects.flatMap(p=>p.images).filter(i=>i.jobId===jobId)
  };
  const aiEngine={
    analyze:(images)=>{
      const scores=images.map(img=>({
        ...img,
        score:Math.min(100,Math.round((img.sharpness||70)+(img.composition||20)+(img.faceDetected?15:0)+(img.exposure>40&&img.exposure<80?10:0)))
      }));
      return scores.sort((a,b)=>b.score-a.score).slice(0,Math.ceil(images.length*0.3));
    },
    suggestLayout:(images,preset)=>{
      const cols=preset.width>preset.height?3:2;
      const rows=Math.ceil(images.length/cols);
      return {cols,rows,cells:images.map((img,i)=>({img,x:(i%cols)*(preset.width/cols),y:Math.floor(i/cols)*(preset.height/rows),w:preset.width/cols,h:preset.height/rows}))};
    }
  };
  const projectStore={
    save(project){
      const idx=state.projects.findIndex(p=>p.id===project.id);
      if(idx>-1)state.projects[idx]=project;else state.projects.push(project);
      localStorage.setItem('evoto_projects',JSON.stringify(state.projects));
    },
    load(id){return state.projects.find(p=>p.id===id)||null;},
    list(){return state.projects.map(({id,name,updatedAt})=>({id,name,updatedAt}));},
    delete(id){state.projects=state.projects.filter(p=>p.id!==id);localStorage.setItem('evoto_projects',JSON.stringify(state.projects));}
  };
  const exportManager={
    async exportProject(projectId,presetName){
      const project=projectStore.load(projectId);
      if(!project)throw new Error('Project not found');
      const preset=state.presets[presetName];
      const layout=aiEngine.suggestLayout(project.images.filter(i=>i.selected),preset);
      const canvas=document.createElement('canvas');
      canvas.width=preset.width;canvas.height=preset.height;
      const ctx=canvas.getContext('2d');
      ctx.fillStyle='#fff';ctx.fillRect(0,0,preset.width,preset.height);
      for(const cell of layout.cells){
        const img=new Image();
        await new Promise(res=>{img.onload=res;img.src=cell.img.src;});
        ctx.drawImage(img,cell.x,cell.y,cell.w,cell.h);
      }
      if(presetName==='pdf'){
        const pdfData=canvas.toDataURL('image/jpeg',0.95);
        return {type:'pdf',data:pdfData,filename:`${project.name}_portfolio.pdf`};
      }
      return {type:'image',data:canvas.toDataURL('image/jpeg',0.92),filename:`${project.name}_${presetName}.jpg`};
    }
  };
  const ui={
    renderProjectList(){
      const list=document.getElementById('project-list');
      if(!list)return;
      list.innerHTML=state.projects.map(p=>`<div class="project-item" data-id="${p.id}"><span>${p.name}</span><small>${new Date(p.updatedAt).toLocaleDateString()}</small></div>`).join('');
      list.querySelectorAll('.project-item').forEach(el=>el.addEventListener('click',()=>this.openProject(el.dataset.id)));
    },
    openProject(id){
      state.currentProject=projectStore.load(id);
      if(!state.currentProject)return;
      const gallery=document.getElementById('gallery');
      if(gallery){
        gallery.innerHTML=state.currentProject.images.map(img=>`<div class="image-card ${img.selected?'selected':''}" data-id="${img.id}"><img src="${img.src}" alt=""><span class="score">${img.score||''}</span></div>`).join('');
        gallery.querySelectorAll('.image-card').forEach(el=>el.addEventListener('click',()=>this.toggleImage(el.dataset.id)));
      }
      this.renderAiSuggestions();
    },
    toggleImage(id){
      const img=state.currentProject.images.find(i=>i.id===id);
      if(img){img.selected=!img.selected;projectStore.save(state.currentProject);this.openProject(state.currentProject.id);}
    },
    renderAiSuggestions(){
      const container=document.getElementById('ai-suggestions');
      if(!container||!state.currentProject)return;
      const suggestions=aiEngine.analyze(state.currentProject.images);
      container.innerHTML=suggestions.map(s=>`<div class="suggestion" data-id="${s.id}"><img src="${s.src}"><button class="accept">✓</button><button class="reject">✗</button></div>`).join('');
      container.querySelectorAll('.accept').forEach(btn=>btn.addEventListener('click',e=>{
        const id=e.target.closest('.suggestion').dataset.id;
        const img=state.currentProject.images.find(i=>i.id===id);
        if(img){img.selected=true;projectStore.save(state.currentProject);this.openProject(state.currentProject.id);}
      }));
      container.querySelectorAll('.reject').forEach(btn=>btn.addEventListener('click',e=>{
        const id=e.target.closest('.suggestion').dataset.id;
        const img=state.currentProject.images.find(i=>i.id===id);
        if(img){img.selected=false;projectStore.save(state.currentProject);this.openProject(state.currentProject.id);}
      }));
    },
    init(){
      this.renderProjectList();
      const uploadBtn=document.getElementById('upload-btn');
      if(uploadBtn)uploadBtn.addEventListener('click',()=>this.handleUpload());
      const exportBtn=document.getElementById('export-btn');
      if(exportBtn)exportBtn.addEventListener('click',()=>this.handleExport());
      const retouchBtn=document.getElementById('retouch
