const app = (() => {
  const state = {
    services: [
      {
        id: 1,
        title: 'Веб-разработка',
        description: 'Создаём современные сайты и веб-приложения любой сложности: от лендингов до корпоративных порталов.',
        icon: '🌐',
        features: ['React / Vue', 'Node.js / Python', 'Адаптивная вёрстка']
      },
      {
        id: 2,
        title: 'Мобильные приложения',
        description: 'Разрабатываем нативные и кроссплатформенные приложения для iOS и Android с фокусом на UX.',
        icon: '📱',
        features: ['React Native', 'Flutter', 'Swift / Kotlin']
      },
      {
        id: 3,
        title: 'UI/UX дизайн',
        description: 'Проектируем интерфейсы, которые нравятся пользователям и приносят бизнесу результат.',
        icon: '🎨',
        features: ['Прототипирование', 'Дизайн-системы', 'Анимация']
      }
    ],
    isModalOpen: false
  };

  const elements = {
    servicesContainer: null,
    modal: null,
    modalOverlay: null,
    form: null,
    closeModalBtn: null,
    openModalBtn: null
  };

  const init = () => {
    cacheDOM();
    bindEvents();
    renderServices();
    renderModal();
  };

  const cacheDOM = () => {
    elements.servicesContainer = document.querySelector('.services-grid');
    elements.openModalBtn = document.querySelector('.cta-button');
  };

  const bindEvents = () => {
    if (elements.openModalBtn) {
      elements.openModalBtn.addEventListener('click', openModal);
    }
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && state.isModalOpen) {
        closeModal();
      }
    });
  };

  const renderServices = () => {
    if (!elements.servicesContainer) return;

    elements.servicesContainer.innerHTML = state.services.map(service => `
      <article class="service-card" data-service-id="${service.id}">
        <div class="service-icon">${service.icon}</div>
        <h3 class="service-title">${service.title}</h3>
        <p class="service-description">${service.description}</p>
        <ul class="service-features">
          ${service.features.map(feature => `<li>${feature}</li>`).join('')}
        </ul>
      </article>
    `).join('');
  };

  const renderModal = () => {
    const modalHTML = `
      <div class="modal-overlay" id="modal-overlay">
        <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
          <button class="modal-close" aria-label="Закрыть окно">×</button>
          <h2 id="modal-title">Оставьте заявку</h2>
          <p class="modal-subtitle">Мы свяжемся с вами в течение 24 часов</p>
          <form id="request-form" novalidate>
            <div class="form-group">
              <label for="name">Ваше имя</label>
              <input type="text" id="name" name="name" placeholder="Иван Иванов" required>
              <span class="error-message"></span>
            </div>
            <div class="form-group">
              <label for="phone">Телефон</label>
              <input type="tel" id="phone" name="phone" placeholder="+7 (___) ___-__-__" required>
              <span class="error-message"></span>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" id="email" name="email" placeholder="example@mail.com" required>
              <span class="error-message"></span>
            </div>
            <div class="form-group">
              <label for="service">Интересующая услуга</label>
              <select id="service" name="service">
                ${state.services.map(service => `<option value="${service.title}">${service.title}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label for="comment">Комментарий</label>
              <textarea id="comment" name="comment" rows="3" placeholder="Опишите вашу задачу..."></textarea>
            </div>
            <button type="submit" class="submit-btn">Отправить заявку</button>
          </form>
          <div class="success-message" hidden>
            <p>✅ Спасибо! Ваша заявка отправлена.</p>
            <p>Мы скоро свяжемся с вами.</p>
          </div>
        </div>
      </div>
    `;

    const modalWrapper = document.createElement('div');
    modalWrapper.innerHTML = modalHTML;
    document.body.appendChild(modalWrapper.firstElementChild);

    elements.modal = document.querySelector('.modal');
    elements.modalOverlay = document.querySelector('.modal-overlay');
    elements.closeModalBtn = document.querySelector('.modal-close');
    elements.form = document.getElementById('request-form');

    if (elements.closeModalBtn) {
      elements.closeModalBtn.addEventListener('click', closeModal);
    }
    if (elements.modalOverlay) {
      elements.modalOverlay.addEventListener('click', (e) => {
        if (e.target === elements.modalOverlay) {
          closeModal();
        }
      });
    }
    if (elements.form) {
      elements.form.addEventListener('submit', handleFormSubmit);
    }
  };

  const openModal = () => {
    state.isModalOpen = true;
    elements.modalOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    setTimeout(() => {
      const firstInput = elements.form?.querySelector('input');
      firstInput?.focus();
    }, 100);
  };

  const closeModal = () => {
    state.isModalOpen = false;
    elements.modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
    resetForm();
  };

  const resetForm = () => {
    if (elements.form) {
      elements.form.reset();
      const errors = elements.form.querySelectorAll('.error-message');
      errors.forEach(error => error.textContent = '');
      const inputs = elements.form.querySelectorAll('input, textarea, select');
      inputs.forEach(input => input.classList.remove('error'));
      const successMessage = document.querySelector('.success-message');
      if (successMessage) successMessage.hidden = true;
      elements.form.hidden = false;
    }
  };

  const handleFormSubmit = (e
